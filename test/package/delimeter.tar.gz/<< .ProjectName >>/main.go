package main

func main() {
	<< .ProjectName >>
	{{ .ProjectName }}
	<< subf 7.5 2 3 >>
}
