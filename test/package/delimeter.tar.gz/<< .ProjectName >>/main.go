package main

func main() {
	<< .ProjectName >>
	{{ .ProjectName }}
}
